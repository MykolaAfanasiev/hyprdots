#!/usr/bin/env bash

set -euo pipefail

PROJECT_ROOT="$(
  cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." &&
    pwd
)"

cd -- "$PROJECT_ROOT"

git config core.hooksPath .githooks

printf 'Git hooks enabled: %s/.githooks\n' "$PROJECT_ROOT"
